import { db } from '../data/database';
import { User } from '../types/database';

export class AuthService {
  static async register(userData: {
    username: string;
    password: string;
    fullName: string;
    email: string;
  }): Promise<User | null> {
    // Проверяем, существует ли пользователь
    const existingUser = db.users.findByUsername(userData.username);
    if (existingUser) {
      return null;
    }

    // Создаем нового пользователя
    const newUser = db.users.create({
      ...userData,
      role: 'student',
      points: 0,
      progress: 0,
      character: 'https://images.unsplash.com/photo-1580541631971-c7f8207ad987?w=400',
      inventory: [],
      groupIds: []
    });

    return newUser;
  }

  static async login(username: string, password: string): Promise<User | null> {
    const user = db.users.findByUsername(username);
    
    if (user && user.password === password) {
      return user;
    }

    return null;
  }
}