import { db } from '../data/database';
import { Group } from '../types/models';

export class GroupService {
  static async createGroup(groupData: {
    name: string;
    teacherId: number;
    level: number;
    description: string;
  }): Promise<Group | null> {
    const teacher = db.users.findById(groupData.teacherId);
    if (!teacher || teacher.role !== 'teacher') {
      return null;
    }

    return db.groups.create({
      ...groupData,
      studentIds: []
    });
  }

  static async addStudentToGroup(groupId: number, studentId: number): Promise<Group | null> {
    const student = db.users.findById(studentId);
    if (!student || student.role !== 'student') {
      return null;
    }

    const group = db.groups.addStudent(groupId, studentId);
    if (group) {
      // Обновляем список групп студента
      const studentData = student as any; // временное решение
      studentData.groupIds = [...(studentData.groupIds || []), groupId];
      db.users.update(studentId, studentData);
    }

    return group || null;
  }

  static async removeStudentFromGroup(groupId: number, studentId: number): Promise<Group | null> {
    const student = db.users.findById(studentId);
    if (!student || student.role !== 'student') {
      return null;
    }

    const group = db.groups.removeStudent(groupId, studentId);
    if (group) {
      // Обновляем список групп студента
      const studentData = student as any; // временное решение
      studentData.groupIds = (studentData.groupIds || []).filter((id: number) => id !== groupId);
      db.users.update(studentId, studentData);
    }

    return group || null;
  }

  static async getTeacherGroups(teacherId: number): Promise<Group[]> {
    return db.groups.findByTeacherId(teacherId);
  }

  static async getStudentGroups(studentId: number): Promise<Group[]> {
    return db.groups.findByStudentId(studentId);
  }
}