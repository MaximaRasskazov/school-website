import { UserStore } from './stores/userStore';
import { ArtifactStore } from './stores/artifactStore';
import { ShopStore } from './stores/shopStore';
import { MonsterStore } from './stores/monsterStore';
import { RuleStore } from './stores/ruleStore';
import { MapStore } from './stores/mapStore';
import { UnderwaterFriendStore } from './stores/underwaterFriendStore';
import { GroupStore } from './stores/groupStore';

export const db = {
  users: new UserStore(),
  artifacts: new ArtifactStore(),
  shop: new ShopStore(),
  monsters: new MonsterStore(),
  rules: new RuleStore(),
  maps: new MapStore(),
  underwaterFriends: new UnderwaterFriendStore(),
  groups: new GroupStore()
};