import { User } from '../../types/models';

export class UserStore {
  private users: User[] = [];
  private currentId = 1;

  create(userData: Omit<User, 'id' | 'created_at'>): User {
    const user: User = {
      id: this.currentId++,
      ...userData,
      created_at: new Date()
    };
    this.users.push(user);
    return user;
  }

  findByUsername(username: string): User | undefined {
    return this.users.find(user => user.username === username);
  }

  findById(id: number): User | undefined {
    return this.users.find(user => user.id === id);
  }

  findByEmail(email: string): User | undefined {
    return this.users.find(user => user.email === email);
  }

  update(id: number, data: Partial<User>): User | undefined {
    const index = this.users.findIndex(user => user.id === id);
    if (index !== -1) {
      this.users[index] = { ...this.users[index], ...data };
      return this.users[index];
    }
    return undefined;
  }

  delete(id: number): boolean {
    const index = this.users.findIndex(user => user.id === id);
    if (index !== -1) {
      this.users.splice(index, 1);
      return true;
    }
    return false;
  }
}