import { Shop } from '../../types/models';

export class ShopStore {
  private purchases: Shop[] = [];
  private currentId = 1;

  create(purchaseData: Omit<Shop, 'id' | 'purchase_date'>): Shop {
    const purchase: Shop = {
      id: this.currentId++,
      ...purchaseData,
      purchase_date: new Date()
    };
    this.purchases.push(purchase);
    return purchase;
  }

  findByUserId(userId: number): Shop[] {
    return this.purchases.filter(purchase => purchase.user_id === userId);
  }

  findByArtifactId(artifactId: number): Shop[] {
    return this.purchases.filter(purchase => purchase.artifact_id === artifactId);
  }
}