import { Monster } from '../../types/models';

export class MonsterStore {
  private monsters: Monster[] = [];
  private currentId = 1;

  create(monsterData: Omit<Monster, 'id'>): Monster {
    const monster: Monster = {
      id: this.currentId++,
      ...monsterData
    };
    this.monsters.push(monster);
    return monster;
  }

  findByUserId(userId: number): Monster[] {
    return this.monsters.filter(monster => monster.user_id === userId);
  }

  updateEvilEnergy(id: number, energy: number): Monster | undefined {
    const monster = this.monsters.find(m => m.id === id);
    if (monster) {
      monster.evil_energy = energy;
      return monster;
    }
    return undefined;
  }
}