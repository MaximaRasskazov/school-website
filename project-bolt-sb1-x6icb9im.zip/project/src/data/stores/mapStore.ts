import { Map } from '../../types/models';

export class MapStore {
  private maps: Map[] = [];
  private currentId = 1;

  create(mapData: Omit<Map, 'id'>): Map {
    const map: Map = {
      id: this.currentId++,
      ...mapData
    };
    this.maps.push(map);
    return map;
  }

  findByUserId(userId: number): Map[] {
    return this.maps.filter(map => map.user_id === userId);
  }

  findByTopic(topic: string): Map[] {
    return this.maps.filter(map => 
      map.topic.toLowerCase().includes(topic.toLowerCase())
    );
  }
}