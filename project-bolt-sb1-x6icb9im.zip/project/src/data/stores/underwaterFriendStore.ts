import { UnderwaterFriend } from '../../types/models';

export class UnderwaterFriendStore {
  private friends: UnderwaterFriend[] = [];
  private currentId = 1;

  create(friendData: Omit<UnderwaterFriend, 'id'>): UnderwaterFriend {
    const friend: UnderwaterFriend = {
      id: this.currentId++,
      ...friendData
    };
    this.friends.push(friend);
    return friend;
  }

  findByUserId(userId: number): UnderwaterFriend[] {
    return this.friends.filter(friend => friend.user_id === userId);
  }

  attachArtifact(friendId: number, artifactId: number): UnderwaterFriend | undefined {
    const friend = this.friends.find(f => f.id === friendId);
    if (friend) {
      friend.artifact_id = artifactId;
      return friend;
    }
    return undefined;
  }

  removeArtifact(friendId: number): UnderwaterFriend | undefined {
    const friend = this.friends.find(f => f.id === friendId);
    if (friend) {
      friend.artifact_id = null;
      return friend;
    }
    return undefined;
  }
}