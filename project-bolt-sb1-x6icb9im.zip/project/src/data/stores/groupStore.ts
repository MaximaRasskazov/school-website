import { Group } from '../../types/models';

export class GroupStore {
  private groups: Group[] = [];
  private currentId = 1;

  create(groupData: Omit<Group, 'id' | 'created_at'>): Group {
    const group: Group = {
      id: this.currentId++,
      ...groupData,
      created_at: new Date()
    };
    this.groups.push(group);
    return group;
  }

  findById(id: number): Group | undefined {
    return this.groups.find(group => group.id === id);
  }

  findByTeacherId(teacherId: number): Group[] {
    return this.groups.filter(group => group.teacherId === teacherId);
  }

  findByStudentId(studentId: number): Group[] {
    return this.groups.filter(group => group.studentIds.includes(studentId));
  }

  addStudent(groupId: number, studentId: number): Group | undefined {
    const group = this.findById(groupId);
    if (group && !group.studentIds.includes(studentId)) {
      group.studentIds.push(studentId);
      return group;
    }
    return undefined;
  }

  removeStudent(groupId: number, studentId: number): Group | undefined {
    const group = this.findById(groupId);
    if (group) {
      group.studentIds = group.studentIds.filter(id => id !== studentId);
      return group;
    }
    return undefined;
  }

  update(id: number, data: Partial<Group>): Group | undefined {
    const index = this.groups.findIndex(group => group.id === id);
    if (index !== -1) {
      this.groups[index] = { ...this.groups[index], ...data };
      return this.groups[index];
    }
    return undefined;
  }

  delete(id: number): boolean {
    const index = this.groups.findIndex(group => group.id === id);
    if (index !== -1) {
      this.groups.splice(index, 1);
      return true;
    }
    return false;
  }
}