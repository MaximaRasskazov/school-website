import { Rule } from '../../types/models';

export class RuleStore {
  private rules: Rule[] = [];
  private currentId = 1;

  create(ruleData: Omit<Rule, 'id' | 'created_at'>): Rule {
    const rule: Rule = {
      id: this.currentId++,
      ...ruleData,
      created_at: new Date()
    };
    this.rules.push(rule);
    return rule;
  }

  findByTeacherId(teacherId: number): Rule[] {
    return this.rules.filter(rule => rule.teacher_id === teacherId);
  }

  findLatest(): Rule[] {
    return [...this.rules].sort((a, b) => 
      b.created_at.getTime() - a.created_at.getTime()
    );
  }
}