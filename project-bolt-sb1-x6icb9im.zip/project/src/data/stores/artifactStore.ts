import { Artifact } from '../../types/models';

export class ArtifactStore {
  private artifacts: Artifact[] = [];
  private currentId = 1;

  create(artifactData: Omit<Artifact, 'id'>): Artifact {
    const artifact: Artifact = {
      id: this.currentId++,
      ...artifactData
    };
    this.artifacts.push(artifact);
    return artifact;
  }

  findById(id: number): Artifact | undefined {
    return this.artifacts.find(artifact => artifact.id === id);
  }

  findAll(): Artifact[] {
    return [...this.artifacts];
  }

  update(id: number, data: Partial<Artifact>): Artifact | undefined {
    const index = this.artifacts.findIndex(artifact => artifact.id === id);
    if (index !== -1) {
      this.artifacts[index] = { ...this.artifacts[index], ...data };
      return this.artifacts[index];
    }
    return undefined;
  }

  delete(id: number): boolean {
    const index = this.artifacts.findIndex(artifact => artifact.id === id);
    if (index !== -1) {
      this.artifacts.splice(index, 1);
      return true;
    }
    return false;
  }
}