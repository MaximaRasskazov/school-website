import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Anchor, User, Lock, AlertCircle } from 'lucide-react';
import { AuthService } from '../services/auth.service';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [error, setError] = useState<string>('');
  const navigate = useNavigate();
  const { setUser } = useAuth();

  const [formData, setFormData] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    email: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      if (isLogin) {
        // Вход
        const user = await AuthService.login(formData.username, formData.password);
        if (user) {
          setUser(user);
          navigate('/profile');
        } else {
          setError('Неверное имя пользователя или пароль');
        }
      } else {
        // Регистрация
        if (formData.password !== formData.confirmPassword) {
          setError('Пароли не совпадают');
          return;
        }

        const user = await AuthService.register({
          username: formData.username,
          password: formData.password,
          fullName: formData.fullName,
          email: formData.email
        });

        if (user) {
          setUser(user);
          navigate('/profile');
        } else {
          setError('Пользователь с таким именем уже существует');
        }
      }
    } catch (err) {
      setError('Произошла ошибка. Попробуйте позже');
    }
  };

  return (
    <div className="flex min-h-[80vh] items-center justify-center">
      <div className="w-full max-w-md rounded-lg bg-white/10 backdrop-blur-lg p-8 shadow-xl">
        <div className="mb-8 text-center">
          <Anchor className="mx-auto mb-4 h-16 w-16 text-blue-200" />
          <h1 className="text-3xl font-bold text-white mb-2">
            {isLogin ? 'Вход' : 'Регистрация'}
          </h1>
          <p className="text-blue-100">Присоединяйтесь к приключению в океане!</p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/20 border border-red-500 rounded-lg flex items-center gap-2 text-red-200">
            <AlertCircle size={20} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-200" size={20} />
              <input
                type="text"
                name="username"
                value={formData.username}
                onChange={handleChange}
                placeholder="Логин"
                className="w-full rounded-lg bg-white/5 p-4 pl-12 text-white placeholder-blue-200 outline-none focus:ring-2 focus:ring-blue-400"
                required
              />
            </div>
          </div>

          {!isLogin && (
            <>
              <div>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-200" size={20} />
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    placeholder="Полное имя"
                    className="w-full rounded-lg bg-white/5 p-4 pl-12 text-white placeholder-blue-200 outline-none focus:ring-2 focus:ring-blue-400"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-200" size={20} />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Email"
                    className="w-full rounded-lg bg-white/5 p-4 pl-12 text-white placeholder-blue-200 outline-none focus:ring-2 focus:ring-blue-400"
                    required
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-200" size={20} />
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Пароль"
                className="w-full rounded-lg bg-white/5 p-4 pl-12 text-white placeholder-blue-200 outline-none focus:ring-2 focus:ring-blue-400"
                required
              />
            </div>
          </div>

          {!isLogin && (
            <div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-200" size={20} />
                <input
                  type="password"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="Подтвердите пароль"
                  className="w-full rounded-lg bg-white/5 p-4 pl-12 text-white placeholder-blue-200 outline-none focus:ring-2 focus:ring-blue-400"
                  required
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full rounded-lg bg-blue-500 p-4 font-bold text-white transition hover:bg-blue-600"
          >
            {isLogin ? 'Войти' : 'Зарегистрироваться'}
          </button>
        </form>

        <div className="mt-6 text-center text-blue-100">
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              setError('');
              setFormData({
                username: '',
                password: '',
                confirmPassword: '',
                fullName: '',
                email: ''
              });
            }}
            className="hover:text-blue-300 transition"
          >
            {isLogin ? 'Нет аккаунта? Зарегистрируйтесь' : 'Уже есть аккаунт? Войдите'}
          </button>
        </div>
      </div>
    </div>
  );
}