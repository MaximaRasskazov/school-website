import React from 'react';
import { ShoppingCart, Shield, Sword } from 'lucide-react';
import Navigation from '../components/Navigation';

export default function Shop() {
  const artifacts = [
    {
      id: '1',
      name: 'Трезубец Посейдона',
      description: 'Легендарное оружие морского бога',
      price: 1000,
      image: 'https://images.unsplash.com/photo-1583394293214-28ded15ee548?w=400',
      type: 'weapon'
    },
    {
      id: '2',
      name: 'Плащ Морских Глубин',
      description: 'Защищает от холодных течений',
      price: 800,
      image: 'https://images.unsplash.com/photo-1551244072-5d12893278ab?w=400',
      type: 'armor'
    },
    {
      id: '3',
      name: 'Щит Атлантиды',
      description: 'Древний щит затонувшей цивилизации',
      price: 1200,
      image: 'https://images.unsplash.com/photo-1597339801934-a8f8d76c6513?w=400',
      type: 'armor'
    }
  ];

  return (
    <div className="container mx-auto p-4">
      <div className="grid grid-cols-1 md:grid-cols-[240px,1fr] gap-8">
        <Navigation />
        
        <div className="space-y-8">
          <div className="flex justify-between items-center">
            <h2 className="text-3xl font-bold text-white">Магазин артефактов</h2>
            <div className="flex items-center gap-2 text-white bg-blue-500/50 rounded-lg px-4 py-2">
              <ShoppingCart />
              <span>1250 монет</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {artifacts.map((artifact) => (
              <div key={artifact.id} className="bg-white/10 backdrop-blur-lg rounded-lg overflow-hidden shadow-xl transform hover:scale-105 transition">
                <div className="h-48 overflow-hidden">
                  <img
                    src={artifact.image}
                    alt={artifact.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    {artifact.type === 'weapon' && <Sword className="text-yellow-400" />}
                    {artifact.type === 'armor' && <Shield className="text-yellow-400" />}
                    <h3 className="text-xl font-bold text-white">{artifact.name}</h3>
                  </div>
                  <p className="text-blue-200 mb-4">{artifact.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold">{artifact.price} монет</span>
                    <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition">
                      Купить
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}