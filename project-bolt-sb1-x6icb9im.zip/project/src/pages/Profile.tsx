import React from 'react';
import { Trophy, Star, Activity } from 'lucide-react';
import Navigation from '../components/Navigation';

export default function Profile() {
  const user = {
    username: "OceanHero",
    fullName: "Александр Морской",
    points: 1250,
    progress: 65,
    character: "https://images.unsplash.com/photo-1580541631971-c7f8207ad987?w=400"
  };

  return (
    <div className="container mx-auto p-4">
      <div className="grid grid-cols-1 md:grid-cols-[240px,1fr] gap-8">
        <Navigation />
        
        <div className="space-y-8">
          <div className="bg-white/10 backdrop-blur-lg rounded-lg p-6 shadow-xl">
            <div className="text-center">
              <img
                src={user.character}
                alt="Character"
                className="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-blue-400"
              />
              <h2 className="text-2xl font-bold text-white mb-2">{user.fullName}</h2>
              <p className="text-blue-200">@{user.username}</p>
            </div>

            <div className="mt-8 space-y-4">
              <div className="flex items-center gap-4 text-white">
                <Trophy className="text-yellow-400" />
                <div className="flex-1">
                  <div className="flex justify-between">
                    <span>Очки</span>
                    <span className="font-bold">{user.points}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4 text-white">
                <Star className="text-yellow-400" />
                <div className="flex-1">
                  <div className="flex justify-between mb-2">
                    <span>Прогресс</span>
                    <span className="font-bold">{user.progress}%</span>
                  </div>
                  <div className="w-full bg-blue-900 rounded-full h-2.5">
                    <div
                      className="bg-blue-400 h-2.5 rounded-full"
                      style={{ width: `${user.progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4 text-white">
                <Activity className="text-yellow-400" />
                <div className="flex-1">
                  <div className="flex justify-between">
                    <span>Уровень</span>
                    <span className="font-bold">{Math.floor(user.points / 100)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-lg p-6 shadow-xl">
            <h3 className="text-xl font-bold text-white mb-4">Достижения</h3>
            <div className="grid grid-cols-2 gap-4">
              {['Спаситель морей', 'Хранитель рифов', 'Друг дельфинов', 'Защитник океана'].map((achievement, index) => (
                <div key={index} className="bg-white/5 rounded-lg p-4">
                  <div className="text-blue-200 font-medium">{achievement}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}