// Базовые типы для пользователей
export interface BaseUser {
  id: string;
  username: string;
  password: string; // В реальном приложении пароль должен быть захэширован
  fullName: string;
  email: string;
  role: 'student' | 'teacher';
}

// Тип для студента
export interface User extends BaseUser {
  points: number;
  progress: number;
  character: string;
  inventory: string[]; // ID предметов в инвентаре
  groupIds: string[]; // ID групп, в которых состоит студент
}

// Тип для учителя
export interface Teacher extends BaseUser {
  specialization: string;
  experience: number;
}

// Тип для группы
export interface Group {
  id: string;
  name: string;
  teacherId: string;
  studentIds: string[];
  level: number;
  description: string;
}