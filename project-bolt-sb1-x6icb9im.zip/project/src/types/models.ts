// Базовые типы сущностей
export interface BaseUser {
  id: number;
  username: string;
  password: string;
  email: string;
  fullName: string;
  role: 'student' | 'teacher';
  created_at: Date;
}

export interface Student extends BaseUser {
  points: number;
  progress: number;
  character: string;
  groupIds: number[];
}

export interface Teacher extends BaseUser {
  specialization: string;
  experience: number;
}

export interface Group {
  id: number;
  name: string;
  teacherId: number;
  studentIds: number[];
  level: number;
  description: string;
  created_at: Date;
}

export interface Artifact {
  id: number;
  name: string;
  description: string | null;
  cost: number;
  image_url: string | null;
}

export interface Shop {
  id: number;
  user_id: number;
  artifact_id: number;
  purchase_date: Date;
}

export interface Monster {
  id: number;
  name: string;
  evil_energy: number;
  user_id: number;
}

export interface Rule {
  id: number;
  teacher_id: number;
  content: string;
  created_at: Date;
}

export interface Map {
  id: number;
  topic: string;
  user_id: number;
  exercise: string;
}

export interface UnderwaterFriend {
  id: number;
  name: string;
  user_id: number;
  artifact_id: number | null;
}