import React from 'react';
import { Outlet } from 'react-router-dom';
import { Waves } from 'lucide-react';

export default function Layout() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-400 to-blue-900">
      <header className="bg-blue-800/50 backdrop-blur-sm p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 text-white">
            <Waves size={32} />
            <span className="text-2xl font-bold">Спасти Океан</span>
          </div>
        </div>
      </header>
      <main className="container mx-auto p-4">
        <Outlet />
      </main>
    </div>
  );
}