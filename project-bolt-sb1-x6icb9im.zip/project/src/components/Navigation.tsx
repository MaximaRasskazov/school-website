import React from 'react';
import { NavLink } from 'react-router-dom';
import { User, ShoppingBag } from 'lucide-react';

export default function Navigation() {
  return (
    <nav className="bg-white/5 backdrop-blur-sm rounded-lg p-4 space-y-2">
      <NavLink
        to="/profile"
        className={({ isActive }) =>
          `flex items-center gap-3 p-3 rounded-lg transition ${
            isActive
              ? 'bg-blue-500 text-white'
              : 'text-blue-100 hover:bg-white/10'
          }`
        }
      >
        <User size={20} />
        <span>Профиль</span>
      </NavLink>
      
      <NavLink
        to="/shop"
        className={({ isActive }) =>
          `flex items-center gap-3 p-3 rounded-lg transition ${
            isActive
              ? 'bg-blue-500 text-white'
              : 'text-blue-100 hover:bg-white/10'
          }`
        }
      >
        <ShoppingBag size={20} />
        <span>Магазин</span>
      </NavLink>
    </nav>
  );
}