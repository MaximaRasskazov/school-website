export interface User {
  username: string;
  fullName: string;
  points: number;
  progress: number;
  character: string;
}

export interface Artifact {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  type: 'weapon' | 'armor' | 'accessory';
}